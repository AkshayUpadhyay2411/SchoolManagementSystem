#ifndef __ENTRY_DETAIL
#define __ENTRY_DETAIL

#include <bits/stdc++.h>
using namespace std;

struct entry_detail
{
    int book_id;
    string name;
    string issue_date;
    string return_date;
};

struct book_detail
{
    int book_id;
    string name;
    int check;
};

#endif
