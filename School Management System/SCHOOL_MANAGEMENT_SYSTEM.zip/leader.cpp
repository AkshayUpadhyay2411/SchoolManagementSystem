#include <bits/stdc++.h>
using namespace std;

#include "leader.h"

void leader::display()
{

    cout << "Displaying leader" << endl;
    cout << "--------------------------------" << endl;

    cout << "Name: " << get_name() << "                     Username: " << get_username() << endl;
    cout << "Roll Number: " << get_roll_no() << endl;
    cout << "Email ID: " << get_email() << endl;
    cout << "Phone No: " << get_phone_no() << endl;
    cout << "Date of Birth: " << get_date_of_birth() << endl;
    cout << "Standard: " << get_standard() << endl;
}

void leader::maintain_the_monitor()
{
    cout << "SHUT UP MONITORS !! ";
}
