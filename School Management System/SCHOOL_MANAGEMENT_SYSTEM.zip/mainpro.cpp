#include <bits/stdc++.h>
using namespace std;

#include "login_system.h"

int main()
{

    cout << "Welcome Sir/Mam\n"
         << "Please login into your account\n";

    LoginSystem login;
    login.login();

    return 0;
}