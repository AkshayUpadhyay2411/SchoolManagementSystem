#ifndef __EXAM_MARKS
#define __EXAM_MARKS

#include <bits/stdc++.h>
using namespace std;

struct exam_marks
{
    int maths_marks;
    int english_marks;
    int hindi_marks;
    int science_marks;
    int social_marks;
    int computer_marks;
};

#endif
