#ifndef __LEADER
#define __LEADER

#include <bits/stdc++.h>
using namespace std;

#include "class_monitor.h"

#include "exam_marks.h"

class leader : public class_monitor
{
public:
    void maintain_the_monitor();
    void display();
};

#endif
